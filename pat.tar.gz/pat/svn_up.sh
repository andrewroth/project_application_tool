#svn up
#sudo fix_permissions this-dir-only
#chgrp spt.campusforchrist.org * -R 2>tmp_out
ruby update.rb
