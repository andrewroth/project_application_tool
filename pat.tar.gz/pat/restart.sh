sudo mongrel-restart /etc/mongrel_cluster/dev.spt.campusforchrist.org.yml

