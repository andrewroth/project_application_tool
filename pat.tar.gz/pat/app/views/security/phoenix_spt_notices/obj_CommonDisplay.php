<table width="530" border="0" cellpadding="10" cellspacing="0">
        <tr>
            <td colspan="2"><p class="bold">Summer Project Tool</p><p class="text"></p></td>
        </tr>
        <tr> 
          <td width="530" height="10" colspan="2" valign="bottom"><?
		      /*
		       * Display Page Content here
		       */
		      echo $pageContent;
		      
		  ?></td>
        </tr>
        <tr> 
          <td colspan="2" valign="top">&nbsp;</td>
        </tr>
        <tr valign="bottom"> 
          <td width="50%" height="35"> <p>&nbsp;</p>
            
         </td>
        </tr>
      </table>