module TravelSegmentsHelper
  def edit_fields
    TravelSegmentsController.edit_fields
  end
end
