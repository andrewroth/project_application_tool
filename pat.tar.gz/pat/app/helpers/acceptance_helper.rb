module AcceptanceHelper
end
