module QuestionnairesHelper
  include PagesRouteMaps
  include ElementsRouteMaps
  include QuestionnaireRouteMaps
end

