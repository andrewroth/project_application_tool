module PagesHelper
  include ElementsRouteMaps
  include PagesRouteMaps
  include QuestionnaireRouteMaps
end

