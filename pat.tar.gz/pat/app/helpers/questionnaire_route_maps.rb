module QuestionnaireRouteMaps
  def import_pages_url(q)
    import_questionnaire_pages_url(q)
  end
  def pages_url(q)
    questionnaire_pages_url(q)
  end
end
