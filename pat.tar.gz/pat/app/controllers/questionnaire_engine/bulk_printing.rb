module BulkPrinting
  def bulk_forms
    project_title = @project.title.to_s
    page_title = @page_title.to_s

    render :inline => "#{project_title} #{page_title}, Generated at #{format_datetime(Time.now)}", :layout => "form_bulk_print"
  end

  def bulk_acceptance_forms(includes = {})
    if params[:viewer_id] && params[:viewer_id] != 'all'
      @items = Acceptance.find_all_by_viewer_id_and_project_id params[:viewer_id], @project.id, :include => includes
    else
      @items = Acceptance.find_all_by_project_id @project.id, :include => includes
    end
    
    @instances = []
    for acc in @items
      next if acc.appln.nil?
      yield acc
    end

    bulk_forms
  end
end

