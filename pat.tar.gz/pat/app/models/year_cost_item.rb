# a cost-item that applies to all projects in the given year
# 
class YearCostItem < CostItem
end
