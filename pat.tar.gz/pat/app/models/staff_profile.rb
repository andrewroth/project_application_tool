class StaffProfile < Profile
end
