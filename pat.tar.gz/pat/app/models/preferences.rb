class Preferences < ActiveRecord::Base
end
