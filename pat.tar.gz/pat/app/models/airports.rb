class Airports < ActiveRecord::Base
end
