# not presently used (-AR)
class ProfileAutoDonation < ProfileDonation
  belongs_to :auto_donation
end
