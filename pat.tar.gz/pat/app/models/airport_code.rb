class AirportCode < ActiveRecord::Base
end
