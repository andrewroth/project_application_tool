class ProfileCostItem < CostItem
  belongs_to :profile
end
