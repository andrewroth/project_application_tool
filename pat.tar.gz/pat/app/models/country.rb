class Country < ActiveRecord::Base
end
