class ReferenceEmail < ActiveRecord::Base
  belongs_to :event_group
end
