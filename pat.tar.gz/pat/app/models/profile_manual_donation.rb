class ProfileManualDonation < ProfileDonation
  belongs_to :manual_donation
end
