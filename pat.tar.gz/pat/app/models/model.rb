class ReportModel < ActiveRecord::Base
end
