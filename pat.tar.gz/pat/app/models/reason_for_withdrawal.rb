class ReasonForWithdrawal < ActiveRecord::Base
end
