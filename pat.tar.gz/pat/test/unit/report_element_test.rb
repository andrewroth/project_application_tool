require File.dirname(__FILE__) + '/../test_helper'

class ReportElementTest < Test::Unit::TestCase
  fixtures :report_elements

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
