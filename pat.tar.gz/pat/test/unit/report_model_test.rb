require File.dirname(__FILE__) + '/../test_helper'

class ReportModelTest < Test::Unit::TestCase
  fixtures :report_models

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
