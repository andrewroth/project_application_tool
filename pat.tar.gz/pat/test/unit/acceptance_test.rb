require File.dirname(__FILE__) + '/../test_helper'

class AcceptanceTest < Test::Unit::TestCase
  #fixtures "ciministry/accountadmin_viewer"
  #fixture :profiles

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
