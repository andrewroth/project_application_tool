require File.dirname(__FILE__) + '/../test_helper'

class ManualDonationTest < Test::Unit::TestCase
  fixtures :manual_donations

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
