require File.dirname(__FILE__) + '/../test_helper'

class SupportCoachTest < Test::Unit::TestCase
  fixtures :support_coaches

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
