require File.dirname(__FILE__) + '/../test_helper'

class EventGroupTest < Test::Unit::TestCase
  fixtures :event_groups

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
