require File.dirname(__FILE__) + '/../../test_helper'

class AssignmentTest < Test::Unit::TestCase
  fixtures "ciministry/cim_hrdb_assignment"
  
  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
