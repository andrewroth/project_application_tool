require File.dirname(__FILE__) + '/../../test_helper'

class VieweraccessgroupTest < Test::Unit::TestCase
  fixtures "ciministry/accountadmin_vieweraccessgroup"

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
