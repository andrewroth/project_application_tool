require File.dirname(__FILE__) + '/../test_helper'

class PreferencesTest < Test::Unit::TestCase
  fixtures :preferences

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
