require File.dirname(__FILE__) + '/../test_helper'

class ProjectCostItemTest < Test::Unit::TestCase
  fixtures :cost_items

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
