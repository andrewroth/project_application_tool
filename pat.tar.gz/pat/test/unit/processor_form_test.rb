require File.dirname(__FILE__) + '/../test_helper'

class ProcessorFormTest < Test::Unit::TestCase
  fixtures :processor_forms

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
