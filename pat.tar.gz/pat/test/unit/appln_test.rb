require File.dirname(__FILE__) + '/../test_helper'

class ApplnTest < Test::Unit::TestCase
  fixtures "ciministry/accountadmin_viewer"
  fixtures :applns

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
