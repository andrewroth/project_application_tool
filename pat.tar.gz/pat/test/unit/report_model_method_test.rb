require File.dirname(__FILE__) + '/../test_helper'

class ReportModelMethodTest < Test::Unit::TestCase
  fixtures :report_model_methods

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
