require File.dirname(__FILE__) + '/../test_helper'

class AcceptanceTravelSegmentTest < Test::Unit::TestCase
  fixtures :profile_travel_segments

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
