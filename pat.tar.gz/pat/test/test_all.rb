require 'test/unit'

#Unit tests.
require File.dirname(__FILE__) + '/test_unit.rb'

#Functional tests.
require File.dirname(__FILE__) + '/test_functional.rb'

#Integration tests.
require File.dirname(__FILE__) + '/test_integration.rb'
