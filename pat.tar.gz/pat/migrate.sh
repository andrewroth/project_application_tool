rake migrate

